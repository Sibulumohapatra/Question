document.addEventListener("DOMContentLoaded", function () {
    fetchCafes();
});

function fetchCafes() {
    // Fetch cafes and places data from the given endpoints
    // You can use Fetch API or XMLHttpRequest for this purpose
    // Example using Fetch API:
    fetch('https://api.example.com/cafes')
        .then(response => response.json())
        .then(data => {
            renderCafes(data);
        })
        .catch(error => {
            console.error('Error fetching cafes:', error);
        });
}

function renderCafes(cafes) {
    const table = document.getElementById('cafeTable');
    table.innerHTML = ''; // Clear previous data

    // Create table header
    const headerRow = table.insertRow(0);
    const headers = ['Name', 'Location']; // Assuming your cafe object has 'name' and 'location' properties

    headers.forEach(headerText => {
        const th = document.createElement('th');
        th.textContent = headerText;
        headerRow.appendChild(th);
    });

    // Create table rows
    cafes.forEach(cafe => {
        const row = table.insertRow();
        const cell1 = row.insertCell(0);
        const cell2 = row.insertCell(1);

        cell1.textContent = cafe.name;
        cell2.textContent = cafe.location;
    });
}

function searchCafes() {
    const searchBox = document.getElementById('searchBox');
    const searchTerm = searchBox.value.toLowerCase();

    // Filter cafes based on the search term
    const filteredCafes = allCafes.filter(cafe => cafe.name.toLowerCase().includes(searchTerm));

    // Render the filtered cafes
    renderCafes(filteredCafes);
}

let allCafes = []; // To store all cafes fetched initially
